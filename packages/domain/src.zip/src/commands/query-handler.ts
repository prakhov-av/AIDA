import type { Query } from "./query";

export interface QueryHandler<
    TQuery extends Query<TResult>,
    TResult,
> {
    execute(query: TQuery): Promise<TResult>;
}